# Changelog

## 0.4.0
- Added external trust/release envelope and explicit self-validation vs authenticity boundary.
- Added compile-request, compiled-pack audience binding, nonce/expiry and materialization receipt.
- Added atomic secure materialization, path/symlink/collision policies.
- Added policy composition result and DENY_OVERRIDES_INTERSECTION_V1.
- Added action→capability registry.
- Added EvidenceEnvelope and evidence invalidation rules.
- Added capability probe provenance and provider certification revocation.
- Added offline schema resolution, payload limits and multi-tenant cache isolation.
- Added semantic validation rules for PhaseResult and DevelopmentPlan DAGs.
- Tightened provider materialization schema.
- Added trust-chain threat controls, release process and SBOM-lite inventory.
- Added negotiation golden vectors and 12 new negative semantic/materialization fixtures.
- Validator expanded with semantic, path-safety, registry and release-hardening checks.


## 0.3.0
- Added canonical registries for phases, capabilities, actions, failure classes, evidence classes, harness capabilities and decision classes.
- Added CompiledHarnessProtocolPack, ProviderCertificationRecord, conformance/eval report, provider question/approval, conflict report and protocol lock schemas.
- Added positive/negative conformance fixtures.
- Validator now validates JSON instances against JSON Schema using jsonschema.
- Added semantic cross-file checks, registry checks, compiler determinism policy and downgrade protection.
- Added eval thresholds and certification policy.
- Added threat model, canonical digest policy, context-budget policy and extension policy.
- Added 0.2→0.3 migration/compatibility rules.


## 0.2.0
- Added machine-readable DevelopmentPhaseProtocol descriptors.
- Added canonical plan/requirement/review/decision/source/failure/repair/verification/bootstrap schemas.
- Added compiler contract, exposure matrix and protocol negotiation rules.
- Added six provider materialization overlays.
- Added precedence, trust, namespace, lifecycle, versioning and approval policies.
- Added HC-01..HC-24 conformance suite.
- Added behavioral eval suite.
- Added validator and examples.
- Added 24-round completeness audit.

## 0.1.0
- Initial canonical phase protocol starter modules and provider profile notes.