# Semantic validation beyond JSON Schema

JSON Schema validates shape, not full runtime meaning.

Required semantic checks include:
- DevelopmentPlan task dependency DAG is acyclic;
- every task dependency refers to an existing task;
- all normative requirements referenced exist;
- `NEEDS_HUMAN_DECISION` requires `human_decision_required=true`;
- other PhaseResult statuses must not falsely assert human decision unless typed accordingly;
- PhaseResult candidate SHA must match trusted Git observation before source phase completion;
- Handoff candidate SHA must equal current candidate at handoff acceptance;
- provider certification must match runtime/adapter/profile versions;
- compiled pack audience must match dispatch target;
- compiled pack must be unexpired and nonce unused;
- no forbidden action can be reintroduced through provider overlay;
- action names must resolve through canonical registries;
- effective action capabilities must be granted by server policy.
