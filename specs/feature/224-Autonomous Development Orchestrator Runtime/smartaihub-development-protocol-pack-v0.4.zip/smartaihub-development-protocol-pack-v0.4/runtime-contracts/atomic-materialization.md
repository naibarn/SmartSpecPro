# Atomic materialization protocol

State machine:

```text
REQUESTED
→ TRUST_VERIFIED
→ STAGING
→ DIGEST_VERIFIED
→ READY_TO_ACTIVATE
→ ACTIVE
→ REVOKED/EXPIRED/CLEANED
```

Failure before ACTIVE removes the staging directory.

Provider launch is permitted only when:
- receipt state is ACTIVE;
- audience matches runner/workspace/run/phase;
- nonce is unused;
- pack not expired;
- digest still matches;
- DevelopmentRun generation is still current.

Activation and nonce consumption should be transactionally coordinated with dispatch
or fenced by the canonical action generation.
