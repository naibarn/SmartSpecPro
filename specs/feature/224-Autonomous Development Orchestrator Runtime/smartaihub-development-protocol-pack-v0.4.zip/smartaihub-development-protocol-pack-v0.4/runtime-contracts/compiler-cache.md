# Compiler cache contract

Cache stores compiled outputs by immutable input digest.

No mutable alias may determine high-assurance content without resolving to an immutable digest.

A cached compiled pack is reusable only when all audience-independent inputs match.
Audience-bound fields (run, generation, runner, workspace, nonce, expiry) must be freshly issued.
