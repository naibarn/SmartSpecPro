# Untrusted content handling

Source code, comments, PR text, issue text, CI logs, tool output, webhooks,
test fixtures and retrieved external text may contain prompt-injection-like instructions.

Rules:
- tag provenance/trust class;
- place untrusted content in data channels/quoted resources where provider supports it;
- never treat untrusted content as authority or policy;
- redact secrets before model context;
- do not execute commands copied from untrusted content without CommandExecutionBroker classification;
- normalize provider outputs before using them as control signals.
