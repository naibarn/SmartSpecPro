# Extension policy

New providers and new phase modules must be addable without editing existing provider semantics.

Requirements:
- unique provider/module identifier;
- schema-valid descriptor;
- namespace policy;
- versioned materialization overlay;
- capability probes;
- conformance report;
- behavioral eval report;
- certification record.

Unknown extensions default to untrusted/provisional.
