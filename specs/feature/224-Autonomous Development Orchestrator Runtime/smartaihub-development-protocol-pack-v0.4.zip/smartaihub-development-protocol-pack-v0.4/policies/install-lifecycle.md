# Installation/materialization lifecycle

Default scope is `RUN_SCOPED` or `WORKSPACE_SCOPED_EPHEMERAL`.

Flow:

1. compile minimal provider pack;
2. validate digest;
3. materialize into isolated workspace/provider extension location;
4. probe provider loading;
5. execute phase;
6. collect PhaseResult;
7. remove/revoke transient pack and credentials;
8. retain manifest/digests in audit evidence.

Global machine installation is opt-in only and never replaces per-run version pinning.
