# Provider question and approval interception

Provider questions/approval prompts MUST normalize to SmartAIHub.

Classify:
- `DERIVABLE_TECHNICAL`: answer from Spec/source/context/policy automatically;
- `LOCAL_SAFE_TECHNICAL`: pre-authorized action may proceed;
- `PRIVILEGE_ESCALATION`: deny or route to authority policy;
- `TRUE_HUMAN_DECISION`: create HumanDecisionRequest.

Providers must not establish a parallel user-decision channel.
