# Context and pack budget

The compiler must minimize provider-visible content.

Rules:
- expose only phase-relevant protocol modules;
- prefer references/resources over full historical transcripts;
- never silently truncate mandatory forbidden actions or output schemas;
- if provider context limits prevent full mandatory protocol delivery,
  return `ALTERNATE_PROVIDER_REQUIRED` or `POLICY_BLOCKED`;
- optional methodology/domain context may be summarized or retrieved lazily.

A pack-size optimization must never weaken authority or verification semantics.
