# Payload and resource limits

Structured control messages must remain bounded.

Recommended server-configurable ceilings:
- PhaseResult JSON: 256 KiB;
- HandoffManifest JSON: 512 KiB;
- compile request: 256 KiB;
- compiled pack metadata: 1 MiB;
- inline provider question: 32 KiB.

Large logs/artifacts use immutable artifact references with digests.

Limits are operational defaults, not a substitute for schema validation.
Exceeding a limit returns a typed failure instead of truncating safety-critical fields.
