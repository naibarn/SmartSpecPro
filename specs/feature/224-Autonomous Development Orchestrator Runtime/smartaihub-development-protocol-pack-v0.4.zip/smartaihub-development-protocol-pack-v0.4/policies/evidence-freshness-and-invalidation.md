# Evidence freshness and invalidation

Evidence is bound to:
- DevelopmentRun;
- phase generation;
- candidate SHA;
- relevant base SHA;
- environment fingerprint when applicable;
- producer/trust level;
- payload digest.

Evidence becomes invalid/stale when its assumptions change, including:
- candidate/source mutation;
- base drift affecting the evidence scope;
- environment/toolchain change;
- test/config change;
- policy/verification profile change where relevant.

A provider-reported claim never upgrades itself to trusted collector evidence.
