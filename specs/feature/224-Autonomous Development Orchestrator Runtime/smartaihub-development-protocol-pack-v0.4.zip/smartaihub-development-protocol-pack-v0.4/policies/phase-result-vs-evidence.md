# PhaseResult vs trusted evidence

A `PhaseResult` reports provider semantic completion.

It cannot mint:
- BuildResult;
- TestResult;
- SecurityScanResult;
- VerificationCertificate.

Those must come from trusted collectors/control-plane services.

Provider statement `tests passed` remains advisory unless linked to trusted evidence.
