# Versioning policy

Pack follows semantic versioning for package artifacts.

Protocol family is independently versioned:
`SAH-DEV-PHASE-1`.

Breaking semantic changes require a new protocol family or an explicitly tested migration.

Every phase dispatch records:
- pack version;
- protocol family/version;
- canonical module digests;
- provider runtime version;
- adapter version;
- provider materialization profile version;
- methodology Skill versions.

Unknown combinations downgrade autonomy until conformance recertification.
