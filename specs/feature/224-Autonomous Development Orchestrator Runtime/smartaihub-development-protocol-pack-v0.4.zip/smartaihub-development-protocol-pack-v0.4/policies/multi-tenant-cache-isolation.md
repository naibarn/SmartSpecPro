# Multi-tenant cache isolation

Compiler/materialization cache keys must include at minimum:
- tenant/org boundary;
- project/repository identity;
- pack release/lock digest;
- protocol family;
- phase;
- provider runtime/profile version;
- authority/policy snapshot digest;
- project context digest.

A cache object created under one tenant must not be reused across tenants unless
the object is explicitly public, content-addressed and contains no tenant/project context.

Cache hit must revalidate integrity before activation.
