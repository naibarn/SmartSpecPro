# Filesystem and path safety

Reject:
- `..` traversal;
- absolute POSIX/Windows/UNC paths;
- drive-relative Windows paths;
- NUL/control characters;
- device/reserved names where target OS treats them specially;
- path aliases that escape the target root;
- symlink/hardlink targets outside the materialization root;
- duplicate paths after Unicode normalization;
- duplicate paths after case-folding on case-insensitive targets.

Provider materializers must operate through a root-confined path resolver.
