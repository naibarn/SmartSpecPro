# Schema resolution policy

High-assurance validation is offline and bundle-pinned.

Rules:
- do not fetch remote `$ref` during validation;
- schema IDs are identifiers, not network-fetch instructions;
- all referenced schemas must exist in the trusted bundled schema registry;
- unknown `$ref` fails closed;
- maximum recursion/depth/document-size limits must be enforced;
- validator implementation/version is part of release provenance.
