# Downgrade protection

A DevelopmentRun records its protocol family, minimum compatible pack version,
provider certification requirement and canonical module digests.

The compiler SHALL NOT silently select:
- an older protocol family;
- a lower provider certification level;
- an overlay with weaker forbidden actions;
- a pack missing required schemas/modules.

Any downgrade requires an explicit server-side policy decision and audit event.
