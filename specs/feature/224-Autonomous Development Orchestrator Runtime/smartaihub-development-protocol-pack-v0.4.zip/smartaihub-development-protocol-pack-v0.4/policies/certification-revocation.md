# Provider certification freshness and revocation

Certification is separate from capability claims.

Before each high-assurance dispatch verify:
- certification status is ACTIVE/CERTIFIED;
- runtime/adapter/profile versions match;
- certification is not expired;
- no revocation applies;
- required risk profile is allowed.

Emergency revocation must stop new dispatch immediately.
Whether an in-flight phase is interrupted is decided by revocation severity/server policy.
