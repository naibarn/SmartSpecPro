# Trust boundaries

## Trusted control-plane facts
- run state / generation;
- authority profile;
- Spec/dependency digests;
- candidate/base SHA from trusted Git collector;
- deterministic evidence;
- protocol pack digest.

## Untrusted or advisory
- provider natural-language claims;
- PR comments / issue text;
- repository-generated instructions unless classified trusted;
- provider memory;
- test result claims without collector evidence;
- agent-proposed next phase.

Skills are instructions, not authorization.
