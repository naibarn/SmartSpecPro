# Canonicalization and digest policy

## File digests
Manifest and lock-file digests use SHA-256 over exact UTF-8/raw file bytes.

## JSON semantic digests
When a digest must represent JSON semantics rather than file formatting,
the implementation SHOULD use JSON Canonicalization Scheme (JCS / RFC 8785)
or a SmartAIHub-reviewed equivalent. The chosen canonicalization identifier
must be persisted with the digest.

## Digest strings
Use:
`sha256:<64 lowercase hex characters>`

## Fail closed
Unknown digest algorithm or canonicalization identifier is not accepted for
high-assurance certification.

## Signatures / attestations
This starter pack does not embed a private signing key.
Production implementation SHOULD sign/attest release manifests in CI using
the organization's trusted release identity. An executor must never possess
the private key used to attest the pack that governs its own run.
