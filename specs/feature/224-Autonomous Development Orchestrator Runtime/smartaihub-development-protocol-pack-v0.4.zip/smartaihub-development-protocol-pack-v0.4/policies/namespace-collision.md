# Namespace and shadowing policy

Reserved SmartAIHub protocol IDs use prefix `sah-`.

Untrusted repository/project Skills MUST NOT shadow a canonical SmartAIHub protocol ID.

Resolution:
1. exact canonical digest match -> allowed;
2. same ID with different digest -> `PROTOCOL_SHADOW_CONFLICT`;
3. untrusted alias claiming canonical ID -> blocked;
4. provider-native mechanism replacing a physical Skill is recorded as a materialization decision, not shadowing.
