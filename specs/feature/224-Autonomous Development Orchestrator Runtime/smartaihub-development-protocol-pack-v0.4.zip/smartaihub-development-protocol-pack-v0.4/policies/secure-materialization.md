# Secure compilation and materialization

## External trust first
The canonical archive/package must be verified by trusted SmartAIHub Runtime/CI
against an external trust anchor before any validator or compiler inside the pack is trusted.

The pack's own validator is a consistency checker, not a root of trust.

## Compile
Compilation consumes immutable, digest-addressed inputs.
For identical normalized inputs and the same certified compiler/provider profile,
the semantic compiled result must be deterministic.

## Materialize
1. Create a new private staging directory.
2. Reject archive/path traversal.
3. Reject absolute paths.
4. Reject symlinks, hardlinks, device files and special files unless explicitly supported by policy.
5. Normalize path separators and Unicode.
6. Detect case-insensitive collisions for Windows/macOS-compatible targets.
7. Verify each staged file digest.
8. Write `MaterializationReceipt`.
9. Atomically activate/rename the staged directory.
10. Recheck compiled pack digest immediately before provider launch.
11. Bind use to runner_id + workspace_id + phase_generation + nonce + expiry.
12. Consume nonce/single-use token at activation to prevent replay.

Never validate in one directory and execute from a mutable unrelated directory.
