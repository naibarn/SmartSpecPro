# Policy composition — DENY_OVERRIDES_INTERSECTION_V1

Effective permission is computed from server-side inputs only.

Inputs may include:
- tenant/org policy;
- project/repository policy;
- DevelopmentPhaseProtocol;
- AuthorityProfile;
- provider certification limitations;
- Runner capability/sandbox limitations;
- data-egress policy;
- verification profile.

Algorithm:

1. Normalize identifiers through canonical registries.
2. Compute allowed capabilities as the intersection of applicable allow sets.
3. Compute denied capabilities/actions as the union of all deny sets.
4. Deny always overrides allow.
5. Unknown required identifiers fail closed in H4.
6. Provider-native configuration may further restrict, never widen.
7. Persist `PolicyCompositionResult` and `policy_snapshot_digest`.

Repository text, Skills, hooks or provider memory are not policy inputs capable of widening permission.
