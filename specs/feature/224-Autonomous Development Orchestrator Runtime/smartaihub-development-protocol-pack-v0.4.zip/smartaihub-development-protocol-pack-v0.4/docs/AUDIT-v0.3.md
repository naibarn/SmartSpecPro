# v0.3 — Third 24-Round Completeness Audit

| # | Dimension | Gap | Improvement |
|---:|---|---|---|
| 1 | Actual JSON Schema validation | v0.2 validator parsed JSON but did not validate instances/descriptors/overlays against schemas | Added jsonschema validation for descriptors, overlays, examples and reports. |
| 2 | Canonical phase vocabulary | Free-form phase strings could drift | Added phase registry and registry checks. |
| 3 | Capability vocabulary | Capability names could diverge across adapters | Added canonical capability registry. |
| 4 | Action vocabulary | Descriptor allowed_actions/forbidden_actions could drift | Added action registry + semantic checks. |
| 5 | Failure taxonomy | Failure classes existed only in Spec prose | Added failure-class registry. |
| 6 | Evidence taxonomy/trust | Evidence references lacked canonical trust classes | Added evidence registry and trust levels. |
| 7 | Harness capability vocabulary | Adapters could invent incompatible capability names | Added harness-capability registry. |
| 8 | Decision taxonomy | Human decision classes lacked pack registry | Added decision-class registry. |
| 9 | Compiled-pack contract | Compiler output had no schema | Added CompiledHarnessProtocolPack schema. |
| 10 | Pack lock / digest semantics | Manifest hashes existed but no canonicalization/lock contract | Added protocol lock, SHA-256 format and canonicalization policy. |
| 11 | Signing/attestation boundary | No production attestation guidance | Added release attestation rule; executor must not hold signing key. |
| 12 | Compiler determinism | Same inputs could materialize different packs | Added deterministic compilation requirement. |
| 13 | Fail-closed context limit | Pack could theoretically be silently truncated | Added context-budget fail-closed policy. |
| 14 | Namespace/preference conflict reporting | Policies existed but no structured conflict report | Added ProtocolConflictReport schema. |
| 15 | Provider question schema | Interception policy lacked machine contract | Added ProviderQuestion schema. |
| 16 | Provider approval schema | Approval interception lacked machine contract | Added ProviderApprovalRequest schema. |
| 17 | Provider certification record | Capability claims were not separate from certification | Added ProviderCertificationRecord. |
| 18 | Conformance report format | HC suite had tests but no result schema | Added HarnessConformanceReport. |
| 19 | Behavioral eval scoring | Metrics existed but no thresholds/report contract | Added thresholds + BehavioralEvalReport. |
| 20 | Positive/negative test vectors | Only one valid fixture existed | Added positive compiled-pack and negative schema fixtures. |
| 21 | Idempotency/correlation | PhaseResult lacked action/idempotency keys | Added action_id/idempotency_key; handoff_id. |
| 22 | Downgrade protection | Old/weak pack could be selected silently | Added downgrade policy and compatibility matrix. |
| 23 | Migration compatibility | No v0.2→v0.3 migration contract | Added migration document and matrix. |
| 24 | Extension/future provider safety | Future provider/module addition rules were implicit | Added extension policy and provisional-default rule. |

## Result

v0.2 was already a useful reference contract pack, but its validator could produce a false sense
of completeness because it did not validate actual instances against JSON Schema.

v0.3 closes that class of gap and adds a formal certification boundary.

The pack is now intended to serve as:
- canonical phase protocol source;
- machine-validated adapter contract;
- provider materialization input;
- conformance/eval contract;
- certification evidence format.

It remains explicitly **non-authoritative for durable lifecycle and Final Verify**.
