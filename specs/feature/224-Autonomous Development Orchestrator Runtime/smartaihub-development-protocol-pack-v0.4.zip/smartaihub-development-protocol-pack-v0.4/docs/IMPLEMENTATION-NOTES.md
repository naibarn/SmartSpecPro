# Implementation notes

Recommended implementation sequence:

1. Commit this pack under a versioned package path.
2. Implement JSON Schema validation server-side.
3. Implement `HarnessCapabilityManifest` probes in provider adapters.
4. Implement Spec 222 `HarnessProtocolPackCompiler`.
5. Start with Codex as the first reference materializer.
6. Validate `PhaseResult` before Spec 224 state reduction.
7. Add provider profiles one by one through HC-01..HC-24.
8. Run behavioral eval fixtures before granting H3/H4 certification.

Do not copy every canonical module physically into every provider.
Use native mechanisms when they satisfy the semantic contract.
