# SmartAIHub Development Protocol Pack v0.4

Canonical provider-facing development protocol pack for **Spec 224 Revision 4**.

This package is a **reference implementation contract pack**, not a durable orchestrator.

## Authority boundary

```text
Spec 224 Runtime
  owns lifecycle / phase transition / recovery / authority / Final Verify

Spec 200 + provider adapters
  own provider session / resume / cancel / events / native feature translation

Spec 222 HarnessProtocolPackCompiler
  materializes this canonical pack into provider-native assets

This pack
  defines bounded phase behavior, schemas, trust rules, provider overlays,
  conformance fixtures and behavioral evals
```

No Skill, hook, agent or provider-local plan mode in this package may become the authoritative lifecycle controller.

## Canonical phase protocol modules

- `sah-plan`
- `sah-implement`
- `sah-debug-repair`
- `sah-review`
- `sah-verify`
- `sah-handoff`
- `sah-repo-safety`
- `sah-requirement-trace`

## Pack layout

```text
protocols/       human-readable protocol modules
descriptors/     machine-readable DevelopmentPhaseProtocol descriptors
schemas/         canonical JSON Schemas
compiler/        compiler/materialization contracts and exposure matrix
providers/       provider-native profiles + materialization overlays
policies/        precedence, trust, namespacing, lifecycle, versioning
conformance/     harness conformance suite HC-01..HC-24
evals/           cross-harness behavioral eval definitions
examples/        valid example envelopes/results/handoffs
tools/           local pack validation
docs/            audit and implementation notes
```

## Integration target

Recommended repository location:

```text
packages/development-protocol-pack/
```

or another versioned package owned by the Spec 222/224 implementation.

## Required runtime behavior

At dispatch time:

```text
DevelopmentPhaseProtocol
+ Project Context Pack
+ Methodology Profile
+ HarnessCapabilityManifest
+ Authority Profile
+ Verification Profile
        ↓
HarnessProtocolPackCompiler
        ↓
minimal RUN_SCOPED provider-native pack
        ↓
provider execution
        ↓
validated PhaseResult
```

Provider natural-language output is supplemental. A valid `PhaseResult` and trusted deterministic evidence remain distinct.

## Validation

Run:

```bash
python tools/validate_pack.py
```

This validates JSON syntax, schema references, descriptor/module consistency,
provider overlays, phase exposure, manifest digests and required files.

## Versioning

Pack version: `0.4.0`  
Protocol family: `SAH-DEV-PHASE-1`  
Spec alignment: `224-r4`

## v0.4 hardening

v0.4 adds:
- canonical vocabularies/registries;
- compiled-pack schema and lock file;
- true JSON Schema instance validation;
- positive and negative conformance fixtures;
- provider certification record/report schemas;
- behavioral eval thresholds;
- compiler determinism/fail-closed requirements;
- digest canonicalization and downgrade protection;
- threat model and extension policy;
- migration/compatibility contract.

## v0.4 trust-chain rule

`tools/validate_pack.py` proves internal consistency, **not authenticity**.

Production order is:

```text
verify trusted release/attestation outside the pack
→ secure extraction
→ validate lock/manifest/schemas/semantics
→ compile
→ audience-bind
→ atomically materialize
→ recheck digest
→ execute
```

Never allow a provider workspace to become the trust root for its own Development Protocol Pack.
