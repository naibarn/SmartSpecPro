# Codex profile

Preferred native mechanisms:
- persisted thread + resume/fork
- thread goal
- streamed events
- native detached review
- workspace sandbox/approval
- Skills where SmartAIHub-specific phase behavior is not natively covered

Rule: do not implement a Codex-local lifecycle controller.

Lifecycle authority: **Spec 224 only.** Provider-native orchestration is phase-local/nested execution.
