# Antigravity profile

Preferred native mechanisms:
- planning mode
- Skills
- custom agents
- hooks
- isolated Git worktree subagents
- teamwork/boost inside bounded phases
- MCP/plugins

Rule: internal teamwork is nested execution, not global lifecycle authority.

Lifecycle authority: **Spec 224 only.** Provider-native orchestration is phase-local/nested execution.
