# Hermes Agent profile

Preferred native mechanisms:
- progressive Skills
- plan mode
- MCP
- delegation/subagents

Rule: SmartAIHub protocol Skills must be protected from agent-managed Skill mutation.

Lifecycle authority: **Spec 224 only.** Provider-native orchestration is phase-local/nested execution.
