# Claude Code / Agent SDK profile

Preferred native mechanisms:
- session resume
- headless JSON / stream-JSON
- plan permission mode
- Agent Skills
- hooks as defense-in-depth
- subagents
- MCP

Rule: provider questions must route through SmartAIHub Decision Classifier.

Lifecycle authority: **Spec 224 only.** Provider-native orchestration is phase-local/nested execution.
