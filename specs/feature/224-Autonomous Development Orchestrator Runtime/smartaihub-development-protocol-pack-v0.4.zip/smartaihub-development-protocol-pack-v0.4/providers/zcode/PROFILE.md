# ZCode profile

Preferred native mechanisms:
- plugin package
- skills/
- agents/
- hooks/
- commands/
- MCP

Rule: capability-probe hooks; do not assume all documented hooks fire on every runtime path.

Lifecycle authority: **Spec 224 only.** Provider-native orchestration is phase-local/nested execution.
