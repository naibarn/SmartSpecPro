# DeepSeek Harness profile

Preferred native mechanisms:
- event-sourced session
- create/resume agent API
- plugin extension points
- plan mode
- Skills registry
- subagent providers
- hook bridges

Rule: pin certified versions for high-assurance use.

Lifecycle authority: **Spec 224 only.** Provider-native orchestration is phase-local/nested execution.
