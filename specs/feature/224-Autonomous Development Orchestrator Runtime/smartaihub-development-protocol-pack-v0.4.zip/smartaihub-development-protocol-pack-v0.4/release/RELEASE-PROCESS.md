# Release process

A production release is created by trusted CI, not by a development harness.

Required:
1. run pack validator and semantic tests;
2. build archive from clean checkout;
3. generate manifest + protocol lock;
4. compute final archive/manifest/lock digests;
5. generate SBOM/provenance metadata;
6. sign/attest release with trusted CI identity;
7. publish immutable artifact;
8. update server-side trusted release registry;
9. never expose signing private key to Runner/provider workspace.

The included release envelope is a template only and is not a production signature.
