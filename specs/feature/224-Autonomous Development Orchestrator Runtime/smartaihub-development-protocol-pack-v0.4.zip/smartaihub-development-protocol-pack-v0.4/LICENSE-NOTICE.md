# License notice

No new public license is asserted by this starter pack.

When integrating into the SmartAIHub repository, apply the repository/project license and
review any third-party methodology/provider assets separately. This pack itself contains
SmartAIHub-authored protocol contracts and provider integration metadata only.
