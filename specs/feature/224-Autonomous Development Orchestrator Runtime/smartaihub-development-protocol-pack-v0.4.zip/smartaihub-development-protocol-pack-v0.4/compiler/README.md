# HarnessProtocolPackCompiler contract

The compiler is owned by the Spec 222 implementation while consuming phase semantics from Spec 224.

It must:

1. load canonical descriptors by digest;
2. validate the current phase exposure matrix;
3. consume a runtime HarnessCapabilityManifest;
4. choose native/provider mechanisms through protocol negotiation;
5. materialize the minimum run-scoped assets;
6. emit a digest-locked `HarnessProtocolPack`;
7. never weaken canonical forbidden actions or authority constraints.

Provider overlay files under `providers/*/materialization.json` are implementation hints/configuration,
not authority.
