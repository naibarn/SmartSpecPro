# Migration 0.2 → 0.3

0.3 keeps protocol family `SAH-DEV-PHASE-1` but hardens packaging/certification.

Required changes:
1. regenerate manifest and protocol lock;
2. include `action_id` and `idempotency_key` in PhaseResult;
3. include `handoff_id` in HarnessHandoffManifest;
4. validate all examples/descriptors/overlays against JSON Schema;
5. adopt canonical registries;
6. generate conformance + behavioral eval reports before certification;
7. record provider certification separately from capability claims;
8. enforce downgrade protection and context-budget fail-closed rules.

Existing 0.2 project context can be reused, but H4 certification must be re-issued.
