# Migration 0.3 → 0.4

Protocol family remains `SAH-DEV-PHASE-1`.

Mandatory for high-assurance:
1. verify canonical pack release through an external trust root;
2. recompile old compiled packs — do not reuse 0.3 compiled artifacts;
3. issue audience-bound pack fields (`runner_id`, `workspace_id`, nonce, expiry);
4. persist compile request/policy/capability/certification digests;
5. implement atomic secure materialization and path/link safety;
6. consume nonce/single-use activation token;
7. implement semantic validation in addition to JSON Schema;
8. reissue provider certification with probe provenance/revocation state;
9. wrap trusted evidence in `EvidenceEnvelope`.

Existing canonical phase descriptors remain protocol-family compatible.
