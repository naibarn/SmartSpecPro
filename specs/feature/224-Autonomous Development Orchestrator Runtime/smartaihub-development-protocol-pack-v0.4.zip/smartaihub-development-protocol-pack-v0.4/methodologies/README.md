# Methodology integration

Methodology Skills are separate from phase protocols.

Examples:
- TDD
- systematic debugging
- root-cause analysis
- security review
- UI visual QA
- migration engineering

The compiler may combine a phase protocol with one or more methodology Skills.
