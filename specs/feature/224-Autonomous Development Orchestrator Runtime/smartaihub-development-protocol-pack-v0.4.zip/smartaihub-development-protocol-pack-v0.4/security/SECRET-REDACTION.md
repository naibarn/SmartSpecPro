# Secret redaction contract

Before provider context/log forwarding, inspect:
- environment variables;
- config files;
- command output;
- Git diffs;
- stack traces;
- URLs/headers;
- generated artifacts.

Use server-managed detectors and allow/deny policy.

Redaction events must retain:
- detector/rule id;
- source reference;
- redacted representation;
- whether execution was blocked.

Never place raw secrets in PhaseResult, HandoffManifest, evidence metadata or provider questions.
