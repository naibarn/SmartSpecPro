# Protocol Pack Threat Model

Protected assets:
- canonical phase semantics;
- forbidden-action rules;
- authority constraints;
- provider materialization decisions;
- certification status.

Threats:
1. repository Skill shadows `sah-*`;
2. provider/plugin mutates canonical instructions;
3. prompt injection from source/comments/tool output;
4. malicious or stale provider overlay;
5. digest substitution;
6. manifest/lock mismatch;
7. downgrade to older weaker protocol;
8. untrusted hook gains authority;
9. provider claims trusted evidence without collector proof;
10. compromised adapter lies about capability support.

Controls:
- reserved namespace;
- digest-locked pack;
- server-side authority;
- runtime capability probes;
- conformance certification;
- signed/attested production releases;
- instruction precedence;
- structured PhaseResult;
- deterministic trusted evidence;
- fail-closed conflict handling;
- downgrade prevention.
