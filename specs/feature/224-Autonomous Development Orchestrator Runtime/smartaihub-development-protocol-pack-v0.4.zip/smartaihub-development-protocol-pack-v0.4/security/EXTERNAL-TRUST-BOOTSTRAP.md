# External trust bootstrap

A package cannot prove its own authenticity.

Production SmartAIHub must maintain a trust root outside the Development Protocol Pack,
for example:
- CI/release attestation identity;
- pinned release digest in trusted server configuration;
- detached signature verified by trusted runtime keyring.

Correct order:

```text
download/locate pack
→ external trust verification
→ secure extraction
→ lock/manifest verification
→ schema/semantic validation
→ compiler eligibility
```

Running `tools/validate_pack.py` before external trust verification is useful for diagnostics
but is not a security boundary.
