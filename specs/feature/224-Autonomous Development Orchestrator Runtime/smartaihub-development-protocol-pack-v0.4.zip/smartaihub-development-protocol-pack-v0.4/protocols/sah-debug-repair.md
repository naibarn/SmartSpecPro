---
name: sah-debug-repair
version: 0.1
class: PHASE_PROTOCOL
owner: SmartAIHub
spec: 224
authoritative_lifecycle_owner: false
---

# SAH Debug Repair

## Objective
Repair a typed failure using evidence and prior-attempt history.

## Required inputs
- Failure classification
- failure evidence
- prior failed strategies
- candidate SHA
- requirement context

## Required behavior
- Form root-cause hypotheses.
- Prefer evidence-driven debugging.
- Avoid repeating failed strategies without new evidence.
- Apply bounded repair.
- Run targeted validation.

## Forbidden behavior
- Do not hide failures.
- Do not delete or weaken tests merely to obtain PASS.
- Do not exceed assigned repair scope.

## Required outputs
- repair summary
- changed files
- targeted validation result refs
- PhaseResult

## Stop conditions
- Repair applied
- Recovery budget exhausted
- Genuine human decision required
- Policy denied

## Authority rule
This module cannot advance the DevelopmentRun state by itself.
It cannot grant new permissions.
It cannot mint trusted Final Verify evidence.
