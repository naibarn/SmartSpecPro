---
name: sah-handoff
version: 0.1
class: PHASE_PROTOCOL
owner: SmartAIHub
spec: 224
authoritative_lifecycle_owner: false
---

# SAH Handoff

## Objective
Produce a provider-neutral handoff for another harness/session without losing run state.

## Required inputs
- current phase
- candidate/base SHA
- validated plan
- findings
- failure history
- evidence refs
- authority constraints

## Required behavior
- Summarize only durable relevant facts.
- Include candidate SHA and protocol versions.
- Preserve open blockers and failed strategies.
- Produce machine-readable HandoffManifest.

## Forbidden behavior
- Do not invent completion state.
- Do not omit known blockers.
- Do not widen authority.

## Required outputs
- HandoffManifest

## Stop conditions
- Valid handoff manifest produced

## Authority rule
This module cannot advance the DevelopmentRun state by itself.
It cannot grant new permissions.
It cannot mint trusted Final Verify evidence.
