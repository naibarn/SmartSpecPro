---
name: sah-repo-safety
version: 0.1
class: PHASE_PROTOCOL
owner: SmartAIHub
spec: 224
authoritative_lifecycle_owner: false
---

# SAH Repository Safety

## Objective
Enforce SmartAIHub repository/source-control safety rules during mutation-capable phases.

## Required inputs
- source-control mode
- protected paths
- allowed remotes
- candidate/base SHA
- authority profile

## Required behavior
- Keep writes in isolated workspace/branch.
- Protect upstream branches.
- Detect test tampering and scope drift.
- Protect secrets and policy files.
- Preserve clean candidate state.

## Forbidden behavior
- No force-push to protected upstream.
- No production credentials in workspace.
- No policy weakening.
- No destructive out-of-scope Git operations.

## Required outputs
- SourceDiffPolicyResult
- safety findings

## Stop conditions
- Safety checks complete
- Policy violation detected

## Authority rule
This module cannot advance the DevelopmentRun state by itself.
It cannot grant new permissions.
It cannot mint trusted Final Verify evidence.
