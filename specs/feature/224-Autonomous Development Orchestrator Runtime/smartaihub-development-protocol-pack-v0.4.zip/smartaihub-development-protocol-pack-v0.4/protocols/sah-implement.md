---
name: sah-implement
version: 0.1
class: PHASE_PROTOCOL
owner: SmartAIHub
spec: 224
authoritative_lifecycle_owner: false
---

# SAH Implement

## Objective
Implement the validated plan within the assigned isolated workspace and scope.

## Required inputs
- Validated plan
- candidate/base SHA
- assigned write scope
- project context
- authority constraints

## Required behavior
- Follow the validated plan.
- Keep changes inside assigned scope.
- Make source changes.
- Run cheap/targeted checks as appropriate.
- Preserve provenance and report changed files.

## Forbidden behavior
- Do not deploy production.
- Do not push protected upstream directly.
- Do not disable tests or Final Verify.
- Do not change authority/policy files to obtain PASS.

## Required outputs
- SourceChangeSet
- candidate SHA or changed working tree state
- normalized PhaseResult

## Stop conditions
- Planned implementation complete
- Genuine human decision required
- Policy denied
- Unrecoverable harness failure

## Authority rule
This module cannot advance the DevelopmentRun state by itself.
It cannot grant new permissions.
It cannot mint trusted Final Verify evidence.
