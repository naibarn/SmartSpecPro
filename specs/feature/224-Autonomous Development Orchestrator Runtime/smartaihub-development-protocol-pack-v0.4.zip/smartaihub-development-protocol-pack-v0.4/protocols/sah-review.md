---
name: sah-review
version: 0.1
class: PHASE_PROTOCOL
owner: SmartAIHub
spec: 224
authoritative_lifecycle_owner: false
---

# SAH Review

## Objective
Independently review the candidate against requirements, correctness, security and maintainability.

## Required inputs
- candidate diff/SHA
- requirement map
- plan
- risk profile
- relevant architecture contracts

## Required behavior
- Review against requirements and architecture boundaries.
- Produce structured findings with severity and evidence.
- Detect scope drift and test tampering.
- Remain read-only unless explicitly delegated otherwise.

## Forbidden behavior
- Do not silently mutate source in review mode.
- Do not declare Final Verify PASS.
- Do not waive blockers without policy authority.

## Required outputs
- ReviewResult
- structured findings
- blocker count

## Stop conditions
- Review completed
- Review evidence unavailable
- Policy denied

## Authority rule
This module cannot advance the DevelopmentRun state by itself.
It cannot grant new permissions.
It cannot mint trusted Final Verify evidence.
