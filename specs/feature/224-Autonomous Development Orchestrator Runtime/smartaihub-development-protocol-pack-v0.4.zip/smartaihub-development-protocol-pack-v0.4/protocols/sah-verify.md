---
name: sah-verify
version: 0.1
class: PHASE_PROTOCOL
owner: SmartAIHub
spec: 224
authoritative_lifecycle_owner: false
---

# SAH Verify

## Objective
Help identify missing evidence and requirement coverage before deterministic Final Verify.

## Required inputs
- EvidenceBundle
- requirement map
- verification profile
- candidate/base SHA

## Required behavior
- Check evidence completeness.
- Map evidence to requirements.
- Identify missing/contradictory evidence.
- Recommend additional verification actions.

## Forbidden behavior
- Do not mint trusted TestResult/BuildResult.
- Do not mark Final Verify PASS.
- Do not treat model claims as deterministic evidence.

## Required outputs
- verification gap report
- evidence mapping
- recommended missing checks

## Stop conditions
- Evidence review complete
- Missing required evidence identified

## Authority rule
This module cannot advance the DevelopmentRun state by itself.
It cannot grant new permissions.
It cannot mint trusted Final Verify evidence.
