"""Tests for CLI tools."""
